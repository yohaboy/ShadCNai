var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/files/route.js")
R.c("server/chunks/[root-of-the-server]__1f8e6a34._.js")
R.c("server/chunks/node_modules_next_dist_bfd7b269._.js")
R.c("server/chunks/[root-of-the-server]__924be513._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_files_route_actions_c1531a43.js")
R.m(780364)
module.exports=R.m(780364).exports
