var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate/route.js")
R.c("server/chunks/[root-of-the-server]__78588f9f._.js")
R.c("server/chunks/node_modules_next_dist_bfd7b269._.js")
R.c("server/chunks/[root-of-the-server]__924be513._.js")
R.c("server/chunks/[root-of-the-server]__78d2d05c._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_generate_route_actions_c237a67b.js")
R.m(989014)
module.exports=R.m(989014).exports
