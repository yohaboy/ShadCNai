module.exports=[356638,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_generate_route_actions_c237a67b.js.map