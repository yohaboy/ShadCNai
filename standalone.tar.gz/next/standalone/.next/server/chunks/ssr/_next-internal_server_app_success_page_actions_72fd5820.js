module.exports=[159914,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_success_page_actions_72fd5820.js.map