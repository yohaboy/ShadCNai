module.exports=[963739,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_files_route_actions_c1531a43.js.map