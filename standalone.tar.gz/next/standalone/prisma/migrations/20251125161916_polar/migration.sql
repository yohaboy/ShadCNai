-- AlterTable
ALTER TABLE "user" ADD COLUMN     "polarCustomerId" TEXT;
