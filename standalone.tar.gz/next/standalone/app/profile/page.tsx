import DashboardLayout from "@/components/profile/Layout";

export default function Profile() {
  return <DashboardLayout />;
}